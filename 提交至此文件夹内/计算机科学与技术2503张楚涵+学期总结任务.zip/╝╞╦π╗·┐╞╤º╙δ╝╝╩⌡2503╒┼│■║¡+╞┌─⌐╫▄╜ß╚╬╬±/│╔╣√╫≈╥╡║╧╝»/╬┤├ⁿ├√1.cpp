#include<stdio.h>
int main(){
	int i;
	int count=0;
	for(i=1;i<=100;i++){
		printf("%4d",i);
		count++;
	if(count%8==0){
		printf("\n");
	}
	}
	return 0;
}
