#include<stdio.h>
int main(){
	int i;
	for(i=10;i<=1000;i++)
		if(i%2==0&&i%3==0&&i%7==0)
			printf("%5d",i);
	return 0;
	}
	
