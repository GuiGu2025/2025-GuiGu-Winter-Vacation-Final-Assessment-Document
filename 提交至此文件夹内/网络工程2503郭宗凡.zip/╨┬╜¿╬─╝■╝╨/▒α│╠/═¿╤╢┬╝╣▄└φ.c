#include <stdio.h>
#include <string.h>  // 必须包含，用于 strcmp

// 1. 修正宏定义：不能用连字符，改用下划线
#define MAX_CONTACTS 100

// 2. 全局变量：所有函数都能访问
struct contact {
    char name[20];
    char phone[30];
};
struct contact contacts[MAX_CONTACTS];
int contact_count = 0;

// 3. 函数声明：全部使用下划线命名（C 语言习惯）
void menu();
void add_contact();
void display_contact();
void search_contact();
void save_to_file();
void load_from_file();

// 4. 主函数
int main() {
    load_from_file();
    int choice;
    while (1) {
        menu();
        scanf("%d", &choice);
        switch (choice) {
            case 1:
                add_contact();
                break;
            case 2:
                display_contact();
                break;
            case 3:
                search_contact();
                break;          // 修正拼写：brrak → break
            case 0:
                save_to_file();
                printf("通讯录已经保存\n");
                return 0;
            default:
                printf("请输入正确选项\n");
        }
    }
}

// 5. 菜单函数
void menu() {
    printf("\n=== 我的通讯录 ===\n");
    printf("1. 添加联系人\n");
    printf("2. 显示所有联系人\n");
    printf("3. 查找联系人\n");
    printf("0. 退出并保存\n");
    printf("请选择: ");
}

// 6. 添加联系人
void add_contact() {
    if (contact_count >= MAX_CONTACTS) {
        printf("通讯录已满！\n");
        return;
    }
    struct contact c;
    printf("姓名：");
    scanf("%s", c.name);
    printf("电话：");
    scanf("%s", c.phone);
    contacts[contact_count] = c;
    contact_count++;
    printf("%s 已添加!\n", c.name);
}

// 7. 显示联系人
void display_contact() {
    if (contact_count == 0) {
        printf("没有联系人\n");
        return; // 加上 return 更清晰
    }
    for (int i = 0; i < contact_count; i++) {
        printf("%s %s\n", contacts[i].name, contacts[i].phone);
    }
}

// 8. 查找联系人
void search_contact() {
    if (contact_count == 0) {
        printf("通讯录为空\n");
        return;
    }

    char name[20]; // 关键：定义要查找的名字
    printf("请输入要查找的姓名: ");
    scanf("%s", name);

    int found = 0;
    for (int i = 0; i < contact_count; i++) {
        if (strcmp(contacts[i].name, name) == 0) { //  使用输入的 name
            printf("找到：%s - %s\n", contacts[i].name, contacts[i].phone);
            found = 1;
        }
    }
    if (!found) {
        printf("未能找到 %s\n", name);
    }
}

// 9. 保存到文件
void save_to_file() {
    FILE *fp = fopen("contacts.txt", "w");
    if (fp == NULL) {
        printf("无法保存文件！\n");
        return;
    }
    for (int i = 0; i < contact_count; i++) {
        fprintf(fp, "%s %s\n", contacts[i].name, contacts[i].phone);
    }
    fclose(fp);
}

// 10. 从文件加载
void load_from_file() {
    FILE *fp = fopen("contacts.txt", "r");
    if (fp == NULL) {
        printf("无历史记录\n");
        return;
    }
    contact_count = 0;
    struct contact c;
    while (fscanf(fp, "%s %s", c.name, c.phone) == 2) {
        contacts[contact_count] = c;
        contact_count++;
        if (contact_count >= MAX_CONTACTS) break;
    }
    fclose(fp);
    printf("成功加载 %d 个联系人。\n", contact_count);
}